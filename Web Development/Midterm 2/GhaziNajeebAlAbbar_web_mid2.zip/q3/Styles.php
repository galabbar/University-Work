<?php

//Name: Ghazi Najeeb Al-Abbar
//ID: 2181148914
//Assignment 4
//Filename: Styles.php

?>

<style>
    ul {

        list-style: none;
    }

    li {

        display: inline;

        margin-right: 100px;

        padding-left: 30px;
        padding-right: 30px;
    }

    a {

        text-decoration: underline;
    }

    h1 {

        margin-bottom: 20px;
    }

    .brdr {

        border: 2px solid black;
    }

    table {

        margin: auto;
    }
</style>