<!DOCTYPE html>
<html>

<body>
    <form method="post" action="cookie.php">
        <p>
            <label>login:</label>
            <input type="text" name="login">
        </p>
        <p>
            <label>password:</label>
            <input type="password" name="pass">
        </p>
        <input type="submit" name="submit" value="submit">
    </form>
</body>

</html>