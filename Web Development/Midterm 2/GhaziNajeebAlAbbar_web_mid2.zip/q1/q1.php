<!DOCTYPE html>
<html>

<head></head>

<body>
    <form method="post" action="page2.php">
        <p>
            <label>enter N</label>
            <input type="text" name="N">
        </p>
        <p>
            <label>enter M</label>
            <input type="text" name="M">
        </p>
        <p>
            <label>enter K</label>
            <input type="text" name="K">
        </p>
        <p>
            <label>enter W</label>
            <input type="text" name="W">
        </p>
        <input type="submit" name="submit" value="submit">
    </form>
</body>

</html>